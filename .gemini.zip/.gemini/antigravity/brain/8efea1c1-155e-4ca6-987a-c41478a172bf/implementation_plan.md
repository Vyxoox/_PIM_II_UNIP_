# Frontend / UX Improvements

## Goal Description
We need to enhance the user experience for form handling in the application by:
1. Providing clear visual feedback for validation errors on the frontend.
2. Standardising the appearance and handling of Flask flash messages across the whole project.

## User Review Required
> [!IMPORTANT]
> Approve the design of the new error‑feedback CSS classes and the flash‑message component before any code modifications are applied.

## Open Questions
> [!WARNING]
> - Do you want the error feedback to appear **inline** (right below the field) *and* with a red border, or only one of these?
> - Should flash messages auto‑dismiss after a few seconds, or stay until the user dismisses them?

## Proposed Changes
---
### Templates
#### [MODIFY] [base.html](file:///c:/Users/vsoliveira/PycharmProjects/Sistema%20de%20busca/templates/base.html)
- Add a reusable Jinja macro for flash messages that applies a consistent style and includes dismiss buttons.

#### [MODIFY] [form_*.html] (all form templates)
- Wrap each input with a container that can display an error message block.
- Ensure the template uses the new macro for field‑specific errors.

---
### Static Assets
#### [NEW] [static/css/flash.css](file:///c:/Users/vsoliveira/PycharmProjects/Sistema%20de%20busca/static/css/flash.css)
- Define CSS classes for flash types: `.flash-success`, `.flash-error`, `.flash-warning`.
- Include a subtle fade‑in animation and a close (×) button.

#### [NEW] [static/css/form-errors.css](file:///c:/Users/vsoliveira/PycharmProjects/Sistema%20de%20busca/static/css/form-errors.css)
- Style `.input-error` to add a red border and a light red background.
- Style `.error-message` for inline error text (small, red, with an icon).
- Add a small transition for focus/blur to improve perception.

#### [MODIFY] [static/js/flash.js](file:///c:/Users/vsoliveira/PycharmProjects/Sistema%20de%20busca/static/js/flash.js)
- Add a helper to auto‑dismiss flash after a configurable timeout (e.g., 5 s).
- Hook the close button to remove the flash element from the DOM.

---
### Backend
#### [MODIFY] [app.py] (or the central Flask app factory)
- Ensure `get_flashed_messages(with_categories=True)` is used in the base template.
- Add a utility function `flash_message(message, category='info')` that prefixes the message with an icon based on the category.

#### [MODIFY] [routes/*] (any route that currently calls `flash(...)`)
- Replace direct `flash('msg', 'error')` calls with the new `flash_message` helper to keep consistency.

## Verification Plan
### Automated Tests
- Run the existing Flask test suite (`pytest`) to ensure no view breakage.
- Add a quick Selenium (or Flask test client) check that a rendered form includes the `.input-error` class when validation fails.
- Verify that a flash message element contains the proper CSS class for its category.

### Manual Verification
- Open the *Novo Servidor* form, submit with missing required fields, and confirm:
  1. Fields show a red border and an inline error message.
  2. A flash banner appears at the top with the `.flash-error` style.
  3. The flash can be dismissed manually and disappears automatically after 5 s.
- Repeat for a successful submission to see the `.flash-success` style.
