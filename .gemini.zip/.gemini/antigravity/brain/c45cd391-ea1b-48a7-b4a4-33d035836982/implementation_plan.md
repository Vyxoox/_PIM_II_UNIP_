# Plano: Fidelidade de Dados na Importação/Exportação e Foto no Banco

## Problemas encontrados

### 🔴 1. `foto_perfil` nunca é gravado no banco
O `foto_service.py` salva corretamente o arquivo em `static/fotos_funcionarios/{id}.jpg`, mas o campo `foto_perfil` na tabela `funcionarios` **nunca é preenchido** — nenhuma rota faz `func.foto_perfil = ...`. A coluna fica sempre `NULL`.

**Impacto**: A exibição funciona só porque o template usa o caminho fixo, mas o banco não reflete o estado real da foto.

**Correção**: Após salvar o arquivo em disco, gravar o caminho relativo (`fotos_funcionarios/{id}.jpg`) no banco. Na remoção, limpar o campo para `None`.

---

### 🟠 2. Ramal gravado com prefixo `173218` no banco
A função `normalizar_ramal` do `app.py` concatena o prefixo `173218` antes do ramal (ex: `8539` → `1732188539`). Isso é gravado assim no banco e exportado assim na planilha.

Na planilha original, o campo `RAMAL(173218)` contém apenas `8539` (sem o prefixo — o nome da coluna já indica o ramal do sistema).

**Impacto**: A planilha exportada terá `1732188539` onde a original tinha `8539`. Re-importar vai duplicar o prefixo: `17321817321888539` etc.

**Correção**: Na exportação, remover o prefixo `173218` antes de gravar na célula do Excel — exibindo apenas os 4 dígitos do ramal.

---

### 🟡 3. Lotação e Área perdem o casing MAIÚSCULO no banco e na exportação
A planilha original tem `38.869 - SERVIÇO DE PATRIMÔNIO...` (tudo maiúsculo).

No banco e no índice Whoosh o valor fica `38.869 - Serviço De Patrimônio...` (capitalizado pela função `normalizar_titulo`).

**Impacto**: A planilha exportada terá casing diferente. Ao re-importar, a `normalizar_area_lotacao` consegue bater pelo código numérico, então não quebra o ciclo — mas o dado fica diferente do original.

**Correção**: Na exportação, exibir os valores de Lotação, Área e Coordenadoria em MAIÚSCULO (já que são codificações padronizadas, não nomes livres).

---

## Correções propostas

### Arquivo: `services/foto_service.py`
- `salvar_foto`: após salvar, retornar o caminho relativo `'fotos_funcionarios/{id}.jpg'`
- `remover_foto`: retornar `None` para indicar remoção

### Arquivo: `routes/criacao.py` e `routes/editfunc.py`
- Após `salvar_foto(...)`: atribuir `func.foto_perfil = resultado` e chamar `db.session.commit()`
- Após `remover_foto(...)`: atribuir `func.foto_perfil = None` e chamar `db.session.commit()`

### Arquivo: `routes/planilha.py`
- Na construção da linha de exportação, para `key == 'ramal'`: remover o prefixo `173218` se presente
- Para `key in ('lotacao', 'area', 'coordenadoria')`: converter para maiúsculo `.upper()`

## Verificação
- Importar planilha → conferir banco
- Exportar → conferir planilha gerada vs. original
- Testar upload de foto → conferir campo `foto_perfil` no banco
